op_version_set = 1
class ConvBlock(Module):
  __parameters__ = []
  training : bool
  n_convs : int
  max_pool : bool
  layer : __torch__.torch.nn.modules.container.___torch_mangle_1.Sequential
  def forward(self: __torch__.models.faced_model.___torch_mangle_2.ConvBlock,
    x: Tensor) -> Tensor:
    return (self.layer).forward(x, )
