op_version_set = 1
class FacedModel(Module):
  __parameters__ = []
  training : bool
  S : int
  B : int
  C : int
  layer1 : __torch__.models.faced_model.ConvBlock
  layer2 : __torch__.models.faced_model.ConvBlock
  layer3 : __torch__.models.faced_model.ConvBlock
  layer4 : __torch__.models.faced_model.ConvBlock
  layer5 : __torch__.models.faced_model.ConvBlock
  layer6 : __torch__.models.faced_model.ConvBlock
  layer7 : __torch__.models.faced_model.___torch_mangle_2.ConvBlock
  layer8 : __torch__.torch.nn.quantized.modules.conv.Conv2d
  quant : __torch__.torch.nn.quantized.modules.Quantize
  dequant : __torch__.torch.nn.quantized.modules.DeQuantize
  def forward(self: __torch__.models.faced_model.FacedModel,
    x: Tensor) -> Tensor:
    x0 = torch._cast_Float(x, False)
    x1 = (self.quant).forward(x0, )
    x2 = (self.layer1).forward(x1, )
    x3 = (self.layer2).forward(x2, )
    x4 = (self.layer3).forward(x3, )
    x5 = (self.layer4).forward(x4, )
    x6 = (self.layer5).forward(x5, )
    x7 = (self.layer6).forward(x6, )
    x8 = (self.layer7).forward(x7, )
    x9 = (self.layer8).forward(x8, )
    return (self.dequant).forward(x9, )
class ConvBlock(Module):
  __parameters__ = []
  training : bool
  n_convs : int
  max_pool : bool
  layer : __torch__.torch.nn.modules.container.Sequential
  def forward(self: __torch__.models.faced_model.ConvBlock,
    x: Tensor) -> Tensor:
    return (self.layer).forward(x, )
