op_version_set = 1
def _max_pool2d(input: Tensor,
    kernel_size: List[int],
    stride: Optional[List[int]]=None,
    padding: List[int],
    dilation: List[int],
    ceil_mode: bool=False,
    return_indices: bool=False) -> Tensor:
  if torch.__is__(stride, None):
    stride0 = annotate(List[int], [])
  else:
    stride0 = unchecked_cast(List[int], stride)
  _0 = torch.max_pool2d(input, kernel_size, stride0, padding, dilation, ceil_mode)
  return _0
