op_version_set = 1
class MaxPool2d(Module):
  __parameters__ = []
  training : bool
  def forward(self: __torch__.torch.nn.modules.pooling.MaxPool2d,
    input: Tensor) -> Tensor:
    _0 = __torch__.torch.nn.functional._max_pool2d
    _1 = _0(input, [2, 2], [2, 2], [0, 0], [1, 1], False, False, )
    return _1
